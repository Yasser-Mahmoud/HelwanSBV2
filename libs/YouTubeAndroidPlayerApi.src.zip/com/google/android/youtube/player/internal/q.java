package com.google.android.youtube.player.internal;

import android.os.RemoteException;

public final class q
  extends RuntimeException
{
  public q(RemoteException paramRemoteException)
  {
    super(paramRemoteException);
  }
}


/* Location:           E:\Android\Workspace\HelwanSBV2\libs\YouTubeAndroidPlayerApi.jar
 * Qualified Name:     com.google.android.youtube.player.internal.q
 * JD-Core Version:    0.7.0.1
 */