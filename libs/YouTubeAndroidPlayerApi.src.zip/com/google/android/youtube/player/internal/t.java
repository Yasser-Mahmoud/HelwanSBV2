package com.google.android.youtube.player.internal;

import com.google.android.youtube.player.YouTubeInitializationResult;

public abstract interface t
{
  public abstract void e();
  
  public abstract void d();
  
  public static abstract interface b
  {
    public abstract void a(YouTubeInitializationResult paramYouTubeInitializationResult);
  }
  
  public static abstract interface a
  {
    public abstract void a();
    
    public abstract void b();
  }
}


/* Location:           E:\Android\Workspace\HelwanSBV2\libs\YouTubeAndroidPlayerApi.jar
 * Qualified Name:     com.google.android.youtube.player.internal.t
 * JD-Core Version:    0.7.0.1
 */