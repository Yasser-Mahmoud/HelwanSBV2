package com.google.android.youtube.player.internal;

import android.os.IBinder;

public abstract interface b
  extends t
{
  public abstract IBinder a();
  
  public abstract k a(j paramj);
  
  public abstract void a(boolean paramBoolean);
}


/* Location:           E:\Android\Workspace\HelwanSBV2\libs\YouTubeAndroidPlayerApi.jar
 * Qualified Name:     com.google.android.youtube.player.internal.b
 * JD-Core Version:    0.7.0.1
 */